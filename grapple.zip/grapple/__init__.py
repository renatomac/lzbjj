'''
Grapple CRM - Core Module
Complete implementation of the main application module

'''
import os
from flask import Flask, render_template, send_from_directory
from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate
from flask_login import LoginManager
from flask_wtf.csrf import CSRFProtect
from flask_moment import Moment
from grapple.config import config
from jinja2_time import TimeExtension


# Initialize extensions
db = SQLAlchemy()
migrate = Migrate()
login_manager = LoginManager()
csrf = CSRFProtect()
moment = Moment()

def create_app(config_name=None):
    # Create and configure the app
    app = Flask(__name__)

    # ADD Jinja2Time
    app.jinja_env.add_extension(TimeExtension)

    # Load configuration
    if config_name is None:
        config_name = os.environ.get('FLASK_CONFIG', 'development')
    app.config.from_object(config[config_name])

    # Initialize extensions with app
    db.init_app(app)
    migrate.init_app(app, db)
    login_manager.init_app(app)
    csrf.init_app(app)
    moment.init_app(app)

    # Configure login manager
    login_manager.login_view = 'auth.login'
    login_manager.login_message = 'Please log in to access this page.'
    login_manager.login_message_category = 'info'

    # Register blueprints
    from grapple.routes.auth import auth_bp
    from grapple.routes.dashboard import dashboard_bp
    from grapple.routes.members import members_bp
    from grapple.routes.classes import classes_bp
    from grapple.routes.attendance import attendance_bp
    from grapple.routes.billing import billing_bp
    from grapple.routes.reports import reports_bp
    from grapple.routes.staff import staff_bp

    app.register_blueprint(auth_bp)
    app.register_blueprint(dashboard_bp)
    app.register_blueprint(members_bp)
    app.register_blueprint(classes_bp)
    app.register_blueprint(attendance_bp)
    app.register_blueprint(billing_bp)
    app.register_blueprint(staff_bp)
    app.register_blueprint(reports_bp)

    # Load user for login manager
    from grapple.models import User

    @login_manager.user_loader
    def load_user(user_id):
        return User.query.get(int(user_id))

    # ** ADDED ROUTE FOR FAVICON **
    @app.route('/favicon.ico')
    def favicon():
        return send_from_directory(os.path.join(app.root_path, 'static'),'favicon.ico', mimetype='image/vnd.microsoft.icon')

    # Register error handlers
    @app.errorhandler(404)
    def page_not_found(e):
        return render_template('errors/404.html'), 404

    @app.errorhandler(500)
    def internal_server_error(e):
        return render_template('errors/500.html'), 500

    # Register template filters
    @app.template_filter('format_date')
    def format_date(value, format='%Y-%m-%d'):
        if value is None:
            return ''
        return value.strftime(format)

    @app.template_filter('format_currency')
    def format_currency(value):
        if value is None:
            return '$0.00'
        return '${:,.2f}'.format(value)

    # Register context processors
    @app.context_processor
    def utility_processor():
        def belt_color_class(belt_rank):
            belt_colors = {
                'white': 'gray',
                'blue': 'blue',
                'purple': 'purple',
                'brown': 'yellow',
                'black': 'black'
            }
            return belt_colors.get(belt_rank.lower(), 'gray')
        return {'belt_color_class': belt_color_class}

    return app

# Import models to ensure they are registered with SQLAlchemy
from grapple import models