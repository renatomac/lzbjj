from flask import Blueprint, render_template, redirect, url_for, flash, request
from flask_login import login_required, current_user
from datetime import datetime, timedelta
from grapple import db
from grapple.models import ClassType, ClassSession, User, Member, class_attendance
from grapple.forms import ClassTypeForm, ClassSessionForm, AttendanceForm

classes_bp = Blueprint('classes', __name__, url_prefix='/classes')

@classes_bp.route('/')
@login_required
def index():
    # Get date range for calendar view
    today = datetime.utcnow().date()
    start_date = request.args.get('start_date', today.strftime('%Y-%m-%d'))
    
    try:
        start_date = datetime.strptime(start_date, '%Y-%m-%d').date()
    except ValueError:
        start_date = today
    
    end_date = start_date + timedelta(days=6)
    
    # Get all class sessions in the date range
    class_sessions = ClassSession.query.filter(
        ClassSession.date.between(start_date, end_date)
    ).order_by(ClassSession.date, ClassSession.start_time).all()
    
    # Organize sessions by day for the calendar view
    calendar_days = []
    current_date = start_date
    while current_date <= end_date:
        day_sessions = [s for s in class_sessions if s.date == current_date]
        calendar_days.append({
            'date': current_date,
            'sessions': day_sessions
        })
        current_date += timedelta(days=1)
    
    # Get all class types for the sidebar
    class_types = ClassType.query.all()
    
    return render_template(
        'classes/index.html', 
        title='Class Schedule',
        calendar_days=calendar_days,
        class_types=class_types,
        start_date=start_date,
        prev_week=start_date - timedelta(days=7),
        next_week=start_date + timedelta(days=7)
    )

@classes_bp.route('/types')
@login_required
def types():
    class_types = ClassType.query.all()
    return render_template('classes/types.html', title='Class Types', class_types=class_types)

@classes_bp.route('/types/create', methods=['GET', 'POST'])
@login_required
def create_type():
    form = ClassTypeForm()
    
    if form.validate_on_submit():
        class_type = ClassType(
            name=form.name.data,
            description=form.description.data,
            level=form.level.data
        )
        
        db.session.add(class_type)
        db.session.commit()
        
        flash(f'Class type "{class_type.name}" has been created!', 'success')
        return redirect(url_for('classes.types'))
    
    return render_template('classes/create_type.html', title='Create Class Type', form=form)

@classes_bp.route('/types//edit', methods=['GET', 'POST'])
@login_required
def edit_type(type_id):
    class_type = ClassType.query.get_or_404(type_id)
    form = ClassTypeForm(obj=class_type)
    
    if form.validate_on_submit():
        form.populate_obj(class_type)
        class_type.updated_at = datetime.utcnow()
        db.session.commit()
        
        flash(f'Class type "{class_type.name}" has been updated!', 'success')
        return redirect(url_for('classes.types'))
    
    return render_template('classes/edit_type.html', title=f'Edit Class Type: {class_type.name}', form=form, class_type=class_type)

""" @classes_bp.route('/create', methods=['GET', 'POST'])
@login_required
def create_session():
    form = ClassSessionForm()
    
    # Populate form choices
    form.class_type_id.choices = [(ct.id, ct.name) for ct in ClassType.query.all()]
    form.instructor_id.choices = [(u.id, f"{u.first_name} {u.last_name}") for u in User.query.filter_by(role='instructor').all()]
    
    if form.validate_on_submit():
        class_session = ClassSession(
            class_type_id=form.class_type_id.data,
            instructor_id=form.instructor_id.data,
            date=form.date.data,
            start_time=form.start_time.data,
            end_time=form.end_time.data,
            capacity=form.capacity.data,
            notes=form.notes.data
        )
        
        db.session.add(class_session)
        db.session.commit()
        
        flash('Class session has been created!', 'success')
        return redirect(url_for('classes.index'))
    
    return render_template('classes/create_session.html', title='Create Class Session', form=form) """

@classes_bp.route('/create', methods=['GET', 'POST'])
@login_required
def create_session():
    form = ClassSessionForm()
    # Populate form choices
    form.class_type_id.choices = [(ct.id, ct.name) for ct in ClassType.query.all()]
    form.instructor_id.choices = [(u.id, u.full_name) for u in User.query.filter_by(is_instructor=True).order_by('full_name').all()]
    
    if form.validate_on_submit():
        class_session = ClassSession(
            class_type_id=form.class_type_id.data,
            instructor_id=form.instructor_id.data,
            date=form.date.data,
            start_time=form.start_time.data,
            end_time=form.end_time.data,
            capacity=form.capacity.data
        )
        db.session.add(class_session)
        db.session.commit()
        
        flash(f'New class session on {class_session.date.strftime("%B %d, %Y")} has been created!', 'success')
        return redirect(url_for('classes.index'))
    
    return render_template('classes/create_session.html', title='Create Class Session', form=form)

@classes_bp.route('/')
@login_required
def view_session(session_id):
    class_session = ClassSession.query.get_or_404(session_id)
    attendees = class_session.attendees.all()
    
    return render_template(
        'classes/view_session.html', 
        title=f'Class: {class_session.class_type.name}',
        class_session=class_session,
        attendees=attendees
    )

@classes_bp.route('/edit', methods=['GET', 'POST'])
@login_required
def edit_session(session_id):
    class_session = ClassSession.query.get_or_404(session_id)
    form = ClassSessionForm(obj=class_session)
    
    # Populate form choices
    form.class_type_id.choices = [(ct.id, ct.name) for ct in ClassType.query.all()]
    form.instructor_id.choices = [(u.id, f"{u.first_name} {u.last_name}") for u in User.query.filter_by(role='instructor').all()]
    
    if form.validate_on_submit():
        form.populate_obj(class_session)
        class_session.updated_at = datetime.utcnow()
        db.session.commit()
        
        flash('Class session has been updated!', 'success')
        return redirect(url_for('classes.view_session', session_id=class_session.id))
    
    return render_template(
        'classes/edit_session.html', 
        title=f'Edit Class: {class_session.class_type.name}',
        form=form,
        class_session=class_session
    )

@classes_bp.route('/attendance', methods=['GET', 'POST'])
@login_required
def take_attendance(session_id):
    class_session = ClassSession.query.get_or_404(session_id)
    
    if request.method == 'POST':
        # Clear existing attendance records
        class_session.attendees.clear()
        
        # Process attendance data
        for key, value in request.form.items():
            if key.startswith('attendance_'):
                member_id = int(key.split('_')[1])
                status = value
                notes = request.form.get(f'notes_{member_id}', '')
                
                # Add attendance record
                stmt = class_attendance.insert().values(
                    member_id=member_id,
                    class_session_id=class_session.id,
                    attendance_status=status,
                    notes=notes,
                    created_at=datetime.utcnow()
                )
                db.session.execute(stmt)
        
        db.session.commit()
        flash('Attendance has been recorded!', 'success')
        return redirect(url_for('classes.view_session', session_id=class_session.id))
    
    # Get all active members
    members = Member.query.filter_by(is_active=True).order_by(Member.last_name).all()
    
    # Get existing attendance records
    attendance_records = {}
    for attendee in class_session.attendees:
        attendance_records[attendee.id] = {
            'status': db.session.query(class_attendance.c.attendance_status).filter(
                class_attendance.c.member_id == attendee.id,
                class_attendance.c.class_session_id == class_session.id
            ).scalar() or 'present',
            'notes': db.session.query(class_attendance.c.notes).filter(
                class_attendance.c.member_id == attendee.id,
                class_attendance.c.class_session_id == class_session.id
            ).scalar() or ''
        }
    
    return render_template(
        'classes/take_attendance.html', 
        title=f'Take Attendance: {class_session.class_type.name}',
        class_session=class_session,
        members=members,
        attendance_records=attendance_records
    )

@classes_bp.route('/delete', methods=['POST'])
@login_required
def delete_session(session_id):
    class_session = ClassSession.query.get_or_404(session_id)
    
    # Store info for flash message
    class_name = class_session.class_type.name
    class_date = class_session.date.strftime('%Y-%m-%d')
    
    # Delete the class session
    db.session.delete(class_session)
    db.session.commit()
    
    flash(f'Class session "{class_name}" on {class_date} has been deleted!', 'success')
    return redirect(url_for('classes.index'))

