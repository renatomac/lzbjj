from flask import Blueprint, render_template, redirect, url_for, flash, request
from flask_login import login_required
from datetime import datetime
from grapple import db
from grapple.models import Member, Membership, MembershipPlan, BeltPromotion
from grapple.forms import MemberForm, MembershipForm, PromotionForm

members_bp = Blueprint('members', __name__, url_prefix='/members')

@members_bp.route('/')
@login_required
def index():
    # Get query parameters for filtering
    search = request.args.get('search', '')
    belt = request.args.get('belt', '')
    status = request.args.get('status', '')
    
    # Base query
    query = Member.query
    
    # Apply filters
    if search:
        query = query.filter(
            (Member.first_name.ilike(f'%{search}%')) | 
            (Member.last_name.ilike(f'%{search}%')) |
            (Member.email.ilike(f'%{search}%'))
        )
    
    if belt:
        query = query.filter(Member.belt_rank == belt)
    
    if status:
        is_active = status == 'active'
        query = query.filter(Member.is_active == is_active)
    
    # Get paginated results
    page = request.args.get('page', 1, type=int)
    members = query.order_by(Member.last_name).paginate(page=page, per_page=20)
    
    return render_template(
        'members/index.html', 
        title='Members', 
        members=members,
        search=search,
        belt=belt,
        status=status
    )

@members_bp.route('/create', methods=['GET', 'POST'])
@login_required
def create():
    form = MemberForm()
    if form.validate_on_submit():
        # Check if the email already exists
        if Member.query.filter_by(email=form.email.data.strip().lower()).first():
            flash('This email is already registered. Please use a different email or contact support.', 'danger')
            return render_template('members/add.html', active_tab='add_member', form=form)
        
        # Proceed with creating the new member
        member = Member(
            first_name=form.first_name.data.strip(),
            last_name=form.last_name.data.strip(),
            nickname=form.nickname.data.strip() if form.nickname.data else None,
            email=form.email.data.strip().lower(),
            phone=form.phone.data.strip() if form.phone.data else None,
            date_of_birth=form.date_of_birth.data,
            gender=form.gender.data,
            address=form.address.data.strip() if form.address.data else None,
            city=form.city.data.strip() if form.city.data else None,
            state=form.state.data,
            zip_code=form.zip_code.data.strip() if form.zip_code.data else None,
            emergency_contact_name=form.emergency_contact_name.data.strip() if form.emergency_contact_name.data else None,
            emergency_contact_phone=form.emergency_contact_phone.data.strip() if form.emergency_contact_phone.data else None,
            emergency_relationship=form.emergency_contact_relationship.data,
            medical_conditions=form.medical_conditions.data.strip() if form.medical_conditions.data else None,
            allergies=form.allergies.data.strip() if form.allergies.data else None,
            liability_waiver=form.liability_waiver.data,
            photo_consent=form.photo_consent.data,
            email_consent=form.email_consent.data,
            belt_rank=form.belt_rank.data,
            stripes=form.stripes.data,
            join_date=form.join_date.data,
            notes=form.notes.data.strip() if form.notes.data else None,
            is_active=form.is_active.data,
        )
        db.session.add(member)
        db.session.commit()
        flash('Member created successfully!', 'success')
        return redirect(url_for('members.view', member_id=member.id))

    return render_template('members/add.html', active_tab='add_member', form=form)

@members_bp.route('/<int:member_id>')
@login_required
def view(member_id):
    member = Member.query.get_or_404(member_id)
    # Get current membership
    current_membership = member.current_membership()
    # Get membership history
    membership_history = Membership.query.filter_by(member_id=member.id).order_by(Membership.start_date.desc()).all()
    # Get promotion history
    promotions = BeltPromotion.query.filter_by(member_id=member.id).order_by(BeltPromotion.promotion_date.desc()).all()
    
    return render_template(
        'members/view.html', 
        title=f'Member: {member.first_name} {member.last_name}',
        member=member,
        current_membership=current_membership,
        membership_history=membership_history,
        promotions=promotions
    )

@members_bp.route('/<int:member_id>/edit', methods=['GET', 'POST'])
@login_required
def edit(member_id):
    member = Member.query.get_or_404(member_id)
    form = MemberForm(obj=member)
    form.member_id = member.id
    if form.validate_on_submit():
        form.populate_obj(member)
        member.updated_at = datetime.utcnow()
        db.session.commit()
        flash(f'Member {member.first_name} {member.last_name} has been updated!', 'success')
        return redirect(url_for('members.view', member_id=member.id))
    return render_template('members/edit.html', title=f'Edit Member: {member.first_name} {member.last_name}', form=form, member=member)

@members_bp.route('/add_membership', methods=['GET', 'POST'])
@login_required
def add_membership(member_id):
    member = Member.query.get_or_404(member_id)
    form = MembershipForm()
    
    # Populate plan choices
    form.plan_id.choices = [(plan.id, plan.name) for plan in MembershipPlan.query.filter_by(is_active=True).all()]
    
    if form.validate_on_submit():
        membership = Membership(
            member_id=member.id,
            plan_id=form.plan_id.data,
            start_date=form.start_date.data,
            end_date=form.end_date.data,
            price_paid=form.price_paid.data,
            payment_status=form.payment_status.data,
            notes=form.notes.data
        )
        
        db.session.add(membership)
        db.session.commit()
        
        flash('Membership has been added!', 'success')
        return redirect(url_for('members.view', member_id=member.id))
    
    return render_template(
        'members/add_membership.html', 
        title=f'Add Membership for {member.first_name} {member.last_name}',
        form=form,
        member=member
    )

@members_bp.route('/toggle_status', methods=['POST'])
@login_required
def toggle_status(member_id):
    member = Member.query.get_or_404(member_id)
    member.is_active = not member.is_active
    member.updated_at = datetime.utcnow()
    db.session.commit()
    
    status = 'activated' if member.is_active else 'deactivated'
    flash(f'Member {member.first_name} {member.last_name} has been {status}!', 'success')
    return redirect(url_for('members.view', member_id=member.id))

@members_bp.route('/export')
@login_required
def export():
    # Implement export logic here
    return "Export not implemented yet"

@members_bp.route('/<int:member_id>/add_promotion', methods=['GET', 'POST'])
@login_required
def add_promotion(member_id):
    member = Member.query.get_or_404(member_id)
    form = PromotionForm()

    # Optionally pre-fill form fields with current member info
    if request.method == 'GET':
        form.previous_belt.data = member.belt_rank
        form.previous_stripes.data = member.stripes

    if form.validate_on_submit():
        promotion = BeltPromotion(
            member_id=member.id,
            previous_belt=member.belt_rank,
            previous_stripes=member.stripes,
            new_belt=form.new_belt.data,
            new_stripes=form.new_stripes.data,
            promotion_date=form.promotion_date.data,
            instructor_id=form.instructor_id.data,
            notes=form.notes.data
        )
        # Update member's belt rank and stripes
        member.belt_rank = form.new_belt.data
        member.stripes = form.new_stripes.data
        member.updated_at = datetime.utcnow()
        db.session.add(promotion)
        db.session.commit()
        flash(f'Belt promotion to {form.new_belt.data.title()} belt with {form.new_stripes.data} stripes has been recorded!', 'success')
        return redirect(url_for('members.view', member_id=member.id))
    return render_template(
        'members/add_promotion.html',
        title=f'Add Belt Promotion for {member.first_name} {member.last_name}',
        form=form,
        member=member
    )