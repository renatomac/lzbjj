from flask import Blueprint, render_template, redirect, url_for, flash, request
from flask_login import login_required
from datetime import datetime, timedelta
from sqlalchemy import func
from grapple import db
from grapple.models import Member, ClassSession, class_attendance

attendance_bp = Blueprint('attendance', __name__, url_prefix='/attendance')

@attendance_bp.route('/')
@login_required
def index():
    # Get date range for attendance report
    today = datetime.utcnow().date()
    start_date = request.args.get('start_date', (today - timedelta(days=30)).strftime('%Y-%m-%d'))
    end_date = request.args.get('end_date', today.strftime('%Y-%m-%d'))
    
    try:
        start_date = datetime.strptime(start_date, '%Y-%m-%d').date()
        end_date = datetime.strptime(end_date, '%Y-%m-%d').date()
    except ValueError:
        start_date = today - timedelta(days=30)
        end_date = today
    
    # Get member filter
    member_id = request.args.get('member_id', None, type=int)
    
    # Base query for attendance records
    query = db.session.query(
        Member,
        func.count(class_attendance.c.class_session_id).label('total_classes'),
        func.sum(func.case([(class_attendance.c.attendance_status == 'present', 1)], else_=0)).label('present_count'),
        func.sum(func.case([(class_attendance.c.attendance_status == 'absent', 1)], else_=0)).label('absent_count'),
        func.sum(func.case([(class_attendance.c.attendance_status == 'late', 1)], else_=0)).label('late_count')
    ).join(
        class_attendance, Member.id == class_attendance.c.member_id
    ).join(
        ClassSession, ClassSession.id == class_attendance.c.class_session_id
    ).filter(
        ClassSession.date.between(start_date, end_date)
    )
    
    if member_id:
        query = query.filter(Member.id == member_id)
    
    attendance_stats = query.group_by(Member.id).all()
    
    # Get all members for the filter dropdown
    members = Member.query.filter_by(is_active=True).order_by(Member.last_name).all()
    
    # Get recent attendance records
    recent_classes = ClassSession.query.filter(
        ClassSession.date.between(start_date, end_date)
    ).order_by(ClassSession.date.desc()).limit(10).all()
    
    return render_template(
        'attendance/index.html', 
        title='Attendance Report',
        attendance_stats=attendance_stats,
        members=members,
        selected_member_id=member_id,
        start_date=start_date,
        end_date=end_date,
        recent_classes=recent_classes
    )

@attendance_bp.route('/member/')
@login_required
def member_attendance(member_id):
    member = Member.query.get_or_404(member_id)
    
    # Get date range
    today = datetime.utcnow().date()
    start_date = request.args.get('start_date', (today - timedelta(days=90)).strftime('%Y-%m-%d'))
    end_date = request.args.get('end_date', today.strftime('%Y-%m-%d'))
    
    try:
        start_date = datetime.strptime(start_date, '%Y-%m-%d').date()
        end_date = datetime.strptime(end_date, '%Y-%m-%d').date()
    except ValueError:
        start_date = today - timedelta(days=90)
        end_date = today
    
    # Get attendance records
    attendance_records = db.session.query(
        ClassSession,
        class_attendance.c.attendance_status,
        class_attendance.c.notes
    ).join(
        class_attendance, ClassSession.id == class_attendance.c.class_session_id
    ).filter(
        class_attendance.c.member_id == member.id,
        ClassSession.date.between(start_date, end_date)
    ).order_by(ClassSession.date.desc()).all()
    
    # Calculate attendance statistics
    total_classes = len(attendance_records)
    present_count = sum(1 for _, status, _ in attendance_records if status == 'present')
    absent_count = sum(1 for _, status, _ in attendance_records if status == 'absent')
    late_count = sum(1 for _, status, _ in attendance_records if status == 'late')
    
    attendance_rate = (present_count / total_classes * 100) if total_classes > 0 else 0
    
    return render_template(
        'attendance/member.html', 
        title=f'Attendance for {member.first_name} {member.last_name}',
        member=member,
        attendance_records=attendance_records,
        start_date=start_date,
        end_date=end_date,
        total_classes=total_classes,
        present_count=present_count,
        absent_count=absent_count,
        late_count=late_count,
        attendance_rate=attendance_rate
    )

@attendance_bp.route('/class/')
@login_required
def class_attendance(session_id):
    class_session = ClassSession.query.get_or_404(session_id)
    
    # Get attendance records
    attendees = db.session.query(
        Member,
        class_attendance.c.attendance_status,
        class_attendance.c.notes
    ).join(
        class_attendance, Member.id == class_attendance.c.member_id
    ).filter(
        class_attendance.c.class_session_id == class_session.id
    ).order_by(Member.last_name).all()
    
    # Calculate attendance statistics
    total_attendees = len(attendees)
    present_count = sum(1 for _, status, _ in attendees if status == 'present')
    absent_count = sum(1 for _, status, _ in attendees if status == 'absent')
    late_count = sum(1 for _, status, _ in attendees if status == 'late')
    
    return render_template(
        'attendance/class.html', 
        title=f'Attendance for {class_session.class_type.name}',
        class_session=class_session,
        attendees=attendees,
        total_attendees=total_attendees,
        present_count=present_count,
        absent_count=absent_count,
        late_count=late_count
    )