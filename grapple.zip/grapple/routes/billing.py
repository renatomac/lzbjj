from flask import Blueprint, render_template, redirect, url_for, flash, request
from flask_login import login_required
from datetime import datetime, timedelta
from sqlalchemy import func
from grapple import db
from grapple.models import Member, Membership, MembershipPlan, Payment
from grapple.forms import MembershipPlanForm, PaymentForm

billing_bp = Blueprint('billing', __name__, url_prefix='/billing')

@billing_bp.route('/')
@login_required
def index():
    # Get date range for billing report
    today = datetime.utcnow().date()
    first_day_of_month = today.replace(day=1)
    last_day_of_month = (first_day_of_month + timedelta(days=32)).replace(day=1) - timedelta(days=1)
    
    start_date = request.args.get('start_date', first_day_of_month.strftime('%Y-%m-%d'))
    end_date = request.args.get('end_date', last_day_of_month.strftime('%Y-%m-%d'))
    
    try:
        start_date = datetime.strptime(start_date, '%Y-%m-%d').date()
        end_date = datetime.strptime(end_date, '%Y-%m-%d').date()
    except ValueError:
        start_date = first_day_of_month
        end_date = last_day_of_month
    
    # Get payment statistics
    total_revenue = db.session.query(func.sum(Payment.amount)).filter(
        func.date(Payment.payment_date).between(start_date, end_date),
        Payment.status == 'completed'
    ).scalar() or 0
    
    payment_count = Payment.query.filter(
        func.date(Payment.payment_date).between(start_date, end_date),
        Payment.status == 'completed'
    ).count()
    
    pending_amount = db.session.query(func.sum(Payment.amount)).filter(
        func.date(Payment.payment_date).between(start_date, end_date),
        Payment.status == 'pending'
    ).scalar() or 0
    
    pending_count = Payment.query.filter(
        func.date(Payment.payment_date).between(start_date, end_date),
        Payment.status == 'pending'
    ).count()
    
    # Get recent payments
    recent_payments = Payment.query.filter(
        func.date(Payment.payment_date).between(start_date, end_date)
    ).order_by(Payment.payment_date.desc()).limit(10).all()
    
    # Get expiring memberships
    thirty_days_from_now = today + timedelta(days=30)
    expiring_memberships = Membership.query.filter(
        Membership.end_date.between(today, thirty_days_from_now),
        Membership.payment_status == 'active'
    ).order_by(Membership.end_date).all()
    
    # Get membership plans
    membership_plans = MembershipPlan.query.filter_by(is_active=True).all()
    
    return render_template(
        'billing/index.html', 
        title='Billing Dashboard',
        start_date=start_date,
        end_date=end_date,
        total_revenue=total_revenue,
        payment_count=payment_count,
        pending_amount=pending_amount,
        pending_count=pending_count,
        recent_payments=recent_payments,
        expiring_memberships=expiring_memberships,
        membership_plans=membership_plans
    )

@billing_bp.route('/plans')
@login_required
def plans():
    membership_plans = MembershipPlan.query.all()
    return render_template('billing/plans.html', title='Membership Plans', membership_plans=membership_plans)

@billing_bp.route('/plans/create', methods=['GET', 'POST'])
@login_required
def create_plan():
    form = MembershipPlanForm()
    
    if form.validate_on_submit():
        plan = MembershipPlan(
            name=form.name.data,
            description=form.description.data,
            price=form.price.data,
            billing_frequency=form.billing_frequency.data,
            classes_per_week=form.classes_per_week.data,
            is_active=form.is_active.data
        )
        
        db.session.add(plan)
        db.session.commit()
        
        flash(f'Membership plan "{plan.name}" has been created!', 'success')
        return redirect(url_for('billing.plans'))
    
    return render_template('billing/create_plan.html', title='Create Membership Plan', form=form)

@billing_bp.route('/plans//edit', methods=['GET', 'POST'])
@login_required
def edit_plan(plan_id):
    plan = MembershipPlan.query.get_or_404(plan_id)
    form = MembershipPlanForm(obj=plan)
    
    if form.validate_on_submit():
        form.populate_obj(plan)
        plan.updated_at = datetime.utcnow()
        db.session.commit()
        
        flash(f'Membership plan "{plan.name}" has been updated!', 'success')
        return redirect(url_for('billing.plans'))
    
    return render_template('billing/edit_plan.html', title=f'Edit Membership Plan: {plan.name}', form=form, plan=plan)

@billing_bp.route('/payments')
@login_required
def payments():
    # Get date range
    today = datetime.utcnow().date()
    start_date = request.args.get('start_date', (today - timedelta(days=30)).strftime('%Y-%m-%d'))
    end_date = request.args.get('end_date', today.strftime('%Y-%m-%d'))
    
    try:
        start_date = datetime.strptime(start_date, '%Y-%m-%d').date()
        end_date = datetime.strptime(end_date, '%Y-%m-%d').date()
    except ValueError:
        start_date = today - timedelta(days=30)
        end_date = today
    
    # Get status filter
    status = request.args.get('status', '')
    
    # Base query
    query = Payment.query.filter(func.date(Payment.payment_date).between(start_date, end_date))
    
    if status:
        query = query.filter(Payment.status == status)
    
    # Get paginated results
    page = request.args.get('page', 1, type=int)
    payments = query.order_by(Payment.payment_date.desc()).paginate(page=page, per_page=20)
    
    return render_template(
        'billing/payments.html', 
        title='Payment History',
        payments=payments,
        start_date=start_date,
        end_date=end_date,
        status=status
    )

@billing_bp.route('/payments/create/', methods=['GET', 'POST'])
@login_required
def create_payment(member_id):
    member = Member.query.get_or_404(member_id)
    form = PaymentForm()
    
    # Get member's current membership
    current_membership = member.current_membership()
    
    if form.validate_on_submit():
        payment = Payment(
            member_id=member.id,
            membership_id=current_membership.id if current_membership else None,
            amount=form.amount.data,
            payment_date=form.payment_date.data,
            payment_method=form.payment_method.data,
            status=form.status.data,
            notes=form.notes.data
        )
        
        db.session.add(payment)
        db.session.commit()
        
        flash(f'Payment of ${payment.amount:.2f} has been recorded for {member.first_name} {member.last_name}!', 'success')
        return redirect(url_for('members.view', member_id=member.id))
    
    return render_template(
        'billing/create_payment.html', 
        title=f'Record Payment for {member.first_name} {member.last_name}',
        form=form,
        member=member,
        current_membership=current_membership
    )

@billing_bp.route('/payments//edit', methods=['GET', 'POST'])
@login_required
def edit_payment(payment_id):
    payment = Payment.query.get_or_404(payment_id)
    form = PaymentForm(obj=payment)
    
    if form.validate_on_submit():
        form.populate_obj(payment)
        db.session.commit()
        
        flash(f'Payment of ${payment.amount:.2f} has been updated!', 'success')
        return redirect(url_for('billing.payments'))
    
    return render_template(
        'billing/edit_payment.html', 
        title='Edit Payment',
        form=form,
        payment=payment
    )