# grapple/routes/staff.py
from flask import Blueprint, render_template, request, redirect, url_for, flash, Response
from sqlalchemy import or_
from grapple.forms import StaffForm, ROLES, PERMS
from grapple.models import db, Staff, RolePermission
import csv, io

staff_bp = Blueprint('staff', __name__, url_prefix='/staff')

def get_summary(qs):
    return {
        'total': qs.count(),
        'active': qs.filter_by(status='active').count(),
        'coaches': qs.filter_by(role='Coach').count(),
    }

@staff_bp.route('/', methods=['GET'])
def index():
    q = request.args.get('q','').strip()
    role = request.args.get('role','').strip()
    status = request.args.get('status','').strip()

    qs = Staff.query
    if q:
        like = f"%{q}%"
        qs = qs.filter(or_(Staff.name.ilike(like), Staff.email.ilike(like), Staff.phone.ilike(like)))
    if role:
        qs = qs.filter(Staff.role==role)
    if status:
        qs = qs.filter(Staff.status==status)

    staff_items = qs.order_by(Staff.name.asc()).all()
    # Convert None to [] for specialties/permissions if needed
    for s in staff_items:
        s.specialties = s.specialties or []
        s.permissions = s.permissions or []

    summary = get_summary(Staff.query)
    return render_template('staff.html',
                           active_tab='list',
                           staff_items=staff_items,
                           roles=ROLES,
                           summary=summary,
                           role_permissions={rp.role: (rp.permissions or []) for rp in RolePermission.query.all()})

@staff_bp.route('/add', methods=['GET','POST'])
def add():
    form = StaffForm()
    if form.validate_on_submit():
        staff = Staff(
            name=form.name.data.strip(),
            role=form.role.data,
            email=form.email.data.strip().lower(),
            phone=form.phone.data.strip() if form.phone.data else None,
            specialties=form.specialties_list(),
            status=form.status.data,
            access_level=form.access_level.data,
            photo_url=form.photo_url.data.strip() if form.photo_url.data else None,
            permissions=form.permissions.data or [],
        )
        db.session.add(staff)
        db.session.commit()
        flash('Staff created!', 'success')
        return redirect(url_for('staff.index'))
    return render_template('staff.html', active_tab='add', form=form,
                           roles=ROLES, summary=get_summary(Staff.query),
                           role_permissions={rp.role: (rp.permissions or []) for rp in RolePermission.query.all()})

@staff_bp.route('/<int:staff_id>/edit', methods=['GET','POST'])
def edit(staff_id):
    s = Staff.query.get_or_404(staff_id)
    form = StaffForm(obj=s)
    # Pre-fill specialties string
    if request.method == 'GET':
        form.specialties.data = ', '.join(s.specialties or [])
    if form.validate_on_submit():
        s.name = form.name.data.strip()
        s.role = form.role.data
        s.email = form.email.data.strip().lower()
        s.phone = form.phone.data.strip() if form.phone.data else None
        s.specialties = form.specialties_list()
        s.status = form.status.data
        s.access_level = form.access_level.data
        s.photo_url = form.photo_url.data.strip() if form.photo_url.data else None
        s.permissions = form.permissions.data or []
        db.session.commit()
        flash('Staff updated!', 'success')
        return redirect(url_for('staff.index'))
    return render_template('staff_edit.html', form=form, staff_item=s)

@staff_bp.route('/<int:staff_id>/delete', methods=['POST'])
def delete(staff_id):
    s = Staff.query.get_or_404(staff_id)
    db.session.delete(s)
    db.session.commit()
    flash('Staff removed.', 'success')
    return redirect(url_for('staff.index'))

@staff_bp.route('/permissions', methods=['GET'])
def permissions():
    return render_template('staff.html', active_tab='permissions',
                           roles=ROLES,
                           role_permissions={rp.role: (rp.permissions or []) for rp in RolePermission.query.all()},
                           summary=get_summary(Staff.query))

@staff_bp.route('/permissions/save', methods=['POST'])
def save_role_permissions():
    # Parse role_perms[Role][]=perm values
    role_perms = request.form.to_dict(flat=False)
    # role_perms will look like {'role_perms[Coach][]':['attendance','members'], ...}
    # Normalize:
    cleaned = {}
    for key, vals in role_perms.items():
        if not key.startswith('role_perms['): continue
        role = key[len('role_perms['):-len('][]')]
        cleaned[role] = vals

    # Upsert each role
    for role, perms in cleaned.items():
        rp = RolePermission.query.filter_by(role=role).first()
        if not rp:
            rp = RolePermission(role=role, permissions=perms)
            db.session.add(rp)
        else:
            rp.permissions = perms
    db.session.commit()
    flash('Role permissions saved.', 'success')
    return redirect(url_for('staff.permissions'))

@staff_bp.route('/export.csv')
def export_csv():
    q = request.args.get('q','').strip()
    role = request.args.get('role','').strip()
    status = request.args.get('status','').strip()
    qs = Staff.query
    if q:
        like = f"%{q}%"
        qs = qs.filter(or_(Staff.name.ilike(like), Staff.email.ilike(like), Staff.phone.ilike(like)))
    if role:
        qs = qs.filter(Staff.role==role)
    if status:
        qs = qs.filter(Staff.status==status)
    rows = qs.order_by(Staff.name.asc()).all()

    def generate():
        output = io.StringIO()
        writer = csv.writer(output)
        writer.writerow(['Name','Role','Email','Phone','Specialties','Status','Access'])
        yield output.getvalue(); output.seek(0); output.truncate(0)
        for s in rows:
            writer.writerow([
                s.name, s.role, s.email, s.phone or '',
                '; '.join(s.specialties or []), s.status, s.access_level
            ])
            yield output.getvalue(); output.seek(0); output.truncate(0)
    return Response(generate(), mimetype='text/csv',
                    headers={'Content-Disposition':'attachment; filename=staff.csv'})