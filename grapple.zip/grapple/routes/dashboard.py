from flask import Blueprint, render_template
from flask_login import login_required
from datetime import datetime, timedelta
from sqlalchemy import func
from grapple.models import Member, ClassSession, Membership, Payment
from grapple import db

dashboard_bp = Blueprint('dashboard', __name__)

@dashboard_bp.route('/')
@dashboard_bp.route('/dashboard')
@login_required
def index():
    # Get total members count
    total_members = Member.query.count()
    
    # Get new members this month
    first_day_of_month = datetime.utcnow().replace(day=1, hour=0, minute=0, second=0, microsecond=0)
    new_members_count = Member.query.filter(Member.join_date >= first_day_of_month).count()
    
    # Get active memberships count
    today = datetime.utcnow().date()
    active_memberships = Membership.query.filter(
        (Membership.end_date >= today) | (Membership.end_date == None),
        Membership.payment_status == 'active'
    ).count()
    
    # Get expiring soon memberships
    thirty_days_from_now = today + timedelta(days=30)
    expiring_soon = Membership.query.filter(
        Membership.end_date.between(today, thirty_days_from_now),
        Membership.payment_status == 'active'
    ).count()
    
    # Get upcoming classes for the next 7 days
    next_week = today + timedelta(days=7)
    upcoming_classes = ClassSession.query.filter(
        ClassSession.date.between(today, next_week)
    ).order_by(ClassSession.date, ClassSession.start_time).all()
    
    # Get classes count for the current week
    start_of_week = today - timedelta(days=today.weekday())
    end_of_week = start_of_week + timedelta(days=6)
    classes_this_week = ClassSession.query.filter(
        ClassSession.date.between(start_of_week, end_of_week)
    ).count()
    
    # Get monthly revenue
    monthly_revenue = db.session.query(func.sum(Payment.amount)).filter(
        Payment.payment_date >= first_day_of_month,
        Payment.status == 'completed'
    ).scalar() or 0
    
    # Get revenue change percentage from last month
    last_month = first_day_of_month - timedelta(days=1)
    first_day_of_last_month = last_month.replace(day=1)
    last_month_revenue = db.session.query(func.sum(Payment.amount)).filter(
        Payment.payment_date.between(first_day_of_last_month, first_day_of_month - timedelta(days=1)),
        Payment.status == 'completed'
    ).scalar() or 0
    
    if last_month_revenue > 0:
        revenue_change = ((monthly_revenue - last_month_revenue) / last_month_revenue) * 100
    else:
        revenue_change = 100 if monthly_revenue > 0 else 0
    
    # Get recent members
    recent_members = Member.query.order_by(Member.join_date.desc()).limit(5).all()
    
    # Get belt distribution
    belt_distribution = {
        'white': 0,
        'blue': 0,
        'purple': 0,
        'brown': 0,
        'black': 0
    }
    
    if total_members > 0:
        for belt in belt_distribution.keys():
            count = Member.query.filter_by(belt_rank=belt).count()
            belt_distribution[belt] = round((count / total_members) * 100)
    
    # Get billing overview
    paid_amount = db.session.query(func.sum(Payment.amount)).filter(
        Payment.payment_date >= first_day_of_month,
        Payment.status == 'completed'
    ).scalar() or 0
    
    paid_count = Payment.query.filter(
        Payment.payment_date >= first_day_of_month,
        Payment.status == 'completed'
    ).count()
    
    pending_amount = db.session.query(func.sum(Payment.amount)).filter(
        Payment.payment_date >= first_day_of_month,
        Payment.status == 'pending'
    ).scalar() or 0
    
    pending_count = Payment.query.filter(
        Payment.payment_date >= first_day_of_month,
        Payment.status == 'pending'
    ).count()
    
    overdue_amount = db.session.query(func.sum(Payment.amount)).filter(
        Payment.payment_date < first_day_of_month,
        Payment.status == 'pending'
    ).scalar() or 0
    
    overdue_count = Payment.query.filter(
        Payment.payment_date < first_day_of_month,
        Payment.status == 'pending'
    ).count()
    
    # Get recent payments
    recent_payments = Payment.query.order_by(Payment.payment_date.desc()).limit(3).all()
    
    return render_template(
        'dashboard/index.html',
        title='Dashboard',
        total_members=total_members,
        new_members_count=new_members_count,
        active_memberships=active_memberships,
        expiring_soon=expiring_soon,
        classes_this_week=classes_this_week,
        monthly_revenue=monthly_revenue,
        revenue_change=revenue_change,
        upcoming_classes=upcoming_classes,
        recent_members=recent_members,
        belt_distribution=belt_distribution,
        paid_amount=paid_amount,
        paid_count=paid_count,
        pending_amount=pending_amount,
        pending_count=pending_count,
        overdue_amount=overdue_amount,
        overdue_count=overdue_count,
        recent_payments=recent_payments
    )