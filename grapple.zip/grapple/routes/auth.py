from flask import Blueprint, render_template, redirect, url_for, flash, request
from flask_login import login_user, logout_user, login_required, current_user
from datetime import datetime
from grapple import db
from grapple.models import User
from grapple.forms import LoginForm, RegistrationForm

auth_bp = Blueprint('auth', __name__, url_prefix='/auth')
    
@auth_bp.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('dashboard.index'))
    
    form = LoginForm()
    if form.validate_on_submit():
        user = User.query.filter_by(username=form.username.data).first()
        
        # --- FIX START ---
        # The redirect was removed from here. If the user or password is invalid,
        # we flash a message and let the function continue to the render_template
        # call at the end. This preserves form data and displays errors.
        if user is None or not user.check_password(form.password.data):
            flash('Invalid username or password', 'danger')
        elif not user.is_active:
            flash('This account has been deactivated. Please contact an administrator.', 'danger')
        else:
            # If credentials and status are valid, log in the user
            login_user(user, remember=form.remember_me.data)
            user.last_login = datetime.utcnow()
            db.session.commit()
            
            next_page = request.args.get('next')
            if not next_page or not next_page.startswith('/'):
                next_page = url_for('dashboard.index')
            
            flash(f'Welcome back, {user.first_name}!', 'success')
            return redirect(next_page)
        # --- FIX END ---

    return render_template('auth/login.html', title='Sign In', form=form, year=datetime.now().year)

@auth_bp.route('/logout')
def logout():
    logout_user()
    flash('You have been logged out.', 'info')
    return redirect(url_for('auth.login'))

@auth_bp.route('/register', methods=['GET', 'POST'])
@login_required
def register():
    if current_user.role != 'admin':
        flash('You do not have permission to register new users.', 'danger')
        return redirect(url_for('dashboard.index'))
    
    form = RegistrationForm()
    if form.validate_on_submit():
        user = User(
            username=form.username.data,
            email=form.email.data,
            first_name=form.first_name.data,
            last_name=form.last_name.data,
            role=form.role.data
        )
        user.set_password(form.password.data)
        db.session.add(user)
        db.session.commit()
        flash(f'User {form.username.data} has been registered!', 'success')
        # --- IMPROVEMENT ---
        # Changed redirect to the dashboard for better UX after registering a user.
        return redirect(url_for('dashboard.index'))
    
    return render_template('auth/register.html', title='Register User', form=form)