# grapple/forms.py
from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, BooleanField, SubmitField, TextAreaField, EmailField
from wtforms import SelectField, DateField, TimeField, IntegerField, DecimalField, TelField, URLField, SelectMultipleField
from wtforms.validators import DataRequired, Email, EqualTo, Length, Optional, ValidationError, DataRequired, URL
from grapple.models import User, Member, MembershipPlan
from grapple import db
from datetime import datetime


class LoginForm(FlaskForm):
    """Form for user login."""
    username = StringField('Username', validators=[DataRequired()])
    password = PasswordField('Password', validators=[DataRequired()])
    remember_me = BooleanField('Remember Me')
    submit = SubmitField('Sign In')


class RegistrationForm(FlaskForm):
    """Form for registering a new user."""
    username = StringField('Username', validators=[DataRequired(), Length(min=3, max=64)])
    email = StringField('Email', validators=[DataRequired(), Email()])
    first_name = StringField('First Name', validators=[DataRequired(), Length(max=64)])
    last_name = StringField('Last Name', validators=[DataRequired(), Length(max=64)])
    password = PasswordField('Password', validators=[DataRequired(), Length(min=8)])
    password2 = PasswordField(
        'Confirm Password', validators=[DataRequired(), EqualTo('password')]
    )
    role = SelectField('Role', choices=[
        ('staff', 'Staff'),
        ('instructor', 'Instructor'),
        ('admin', 'Administrator')
    ])
    submit = SubmitField('Register')
    
    def validate_username(self, username):
        user = User.query.filter_by(username=username.data).first()
        if user is not None:
            raise ValidationError('Please use a different username.')

    def validate_email(self, email):
        user = User.query.filter_by(email=email.data).first()
        if user is not None:
            raise ValidationError('Please use a different email address.')


class MemberForm(FlaskForm):
    """Form for creating and editing members."""
    first_name = StringField('First Name', validators=[DataRequired(), Length(max=64)])
    last_name = StringField('Last Name', validators=[DataRequired(), Length(max=64)])
    nickname = StringField('Nickname', validators=[Optional(), Length(max=64)])
    email = StringField('Email', validators=[DataRequired(), Email(), Length(max=120)])
    phone = StringField('Phone', validators=[Optional(), Length(max=20)])
    gender = SelectField('Gender', choices=[('male', 'Male'), ('female', 'Female'), ('other', 'Other')], validators=[Optional()])
    date_of_birth = DateField('Date of Birth', validators=[Optional()])
    address = StringField('Address', validators=[Optional(), Length(max=255)])
    city = StringField('City', validators=[Optional(), Length(max=100)])
    state = StringField('State', validators=[Optional(), Length(max=2)])
    zip_code = StringField('Zip Code', validators=[Optional(), Length(max=10)])
    join_date = DateField('Join Date', validators=[DataRequired()])
    belt_rank = SelectField('Belt Rank', choices=[
        ('white', 'White'), ('blue', 'Blue'), ('purple', 'Purple'), ('brown', 'Brown'), ('black', 'Black')
    ], validators=[DataRequired()])
    stripes = SelectField('Stripes', choices=[
        ('0', '0'), ('1', '1'), ('2', '2'), ('3', '3'), ('4', '4')
    ], coerce=int, validators=[Optional()])
    is_active = BooleanField('Is Active', default='checked', validators=[Optional()])
    notes = TextAreaField('Notes', validators=[Optional()])
    submit = SubmitField('Save Member')
    zip_code = StringField('Zip Code', validators=[Optional(), Length(max=10)])
    emergency_contact_name = StringField('Emergency Contact Name', validators=[Optional(), Length(max=100)])
    emergency_contact_phone = StringField('Emergency Contact Phone', validators=[Optional(), Length(max=20)])
    emergency_contact_relationship = StringField('Emergency Contact Relationship', validators=[Optional(), Length(max=50)])
    join_date = DateField('Join Date', validators=[DataRequired()])
    membership_plan = SelectField('Membership Plan', choices=[('regular', 'Regular'), ('family', 'Family'), ('law_enforcement', 'Law Enforcement')], validators=[DataRequired()])
    medical_conditions = TextAreaField('Medical Conditions', validators=[Optional()])
    allergies = TextAreaField('Allergies', validators=[Optional()])
    #last_updated = DateTimeField('Last Updated', validators=[Optional()])
    #created_at = DateTimeField('Created At', validators=[Optional()])
    liability_waiver = BooleanField('Liability Waiver Signed', default=False, validators=[Optional()])
    photo_consent = BooleanField('Photo Consent Granted', default=False, validators=[Optional()])
    email_consent = BooleanField('Email Consent Granted', default=False, validators=[Optional()])
    
    


class MembershipPlanForm(FlaskForm):
    """Form for creating and editing membership plans."""
    name = StringField('Plan Name', validators=[DataRequired(), Length(max=128)])
    price = DecimalField('Monthly Price', validators=[DataRequired()])
    duration_months = IntegerField('Duration (months)', validators=[Optional()])
    description = TextAreaField('Description', validators=[Optional()])
    submit = SubmitField('Save Plan')


class MembershipForm(FlaskForm):
    """Form for assigning a membership to a member."""
    start_date = DateField('Start Date', validators=[DataRequired()])
    end_date = DateField('End Date', validators=[Optional()])
    payment_status = SelectField('Payment Status', choices=[
        ('paid', 'Paid'), ('pending', 'Pending'), ('late', 'Late'), ('expired', 'Expired')
    ], validators=[DataRequired()])
    notes = TextAreaField('Notes', validators=[Optional()])
    submit = SubmitField('Save Membership')


class PaymentForm(FlaskForm):
    """Form for recording a payment."""
    amount = DecimalField('Amount', validators=[DataRequired()])
    payment_date = DateField('Payment Date', validators=[DataRequired()])
    payment_method = SelectField('Payment Method', choices=[
        ('credit_card', 'Credit Card'), ('cash', 'Cash'), ('check', 'Check'), ('bank_transfer', 'Bank Transfer')
    ], validators=[DataRequired()])
    status = SelectField('Status', choices=[
        ('paid', 'Paid'), ('pending', 'Pending'), ('refunded', 'Refunded')
    ], validators=[DataRequired()])
    notes = TextAreaField('Notes', validators=[Optional()])
    submit = SubmitField('Record Payment')


class ClassTypeForm(FlaskForm):
    """Form for creating and editing a class type."""
    name = StringField('Class Name', validators=[DataRequired(), Length(max=64)])
    description = TextAreaField('Description', validators=[Optional()])
    level = SelectField('Belt Level', choices=[
        ('beginner', 'Beginner'), ('intermediate', 'Intermediate'), ('advanced', 'Advanced'), ('all-levels', 'All Levels')
    ], validators=[Optional()])
    submit = SubmitField('Save Class Type')


class ClassSessionForm(FlaskForm):
    """Form for scheduling a specific class session."""
    class_type_id = SelectField('Class Type', coerce=int, validators=[DataRequired()])
    instructor_id = SelectField('Instructor', coerce=int, validators=[DataRequired()])
    date = DateField('Date', validators=[DataRequired()])
    start_time = TimeField('Start Time', validators=[DataRequired()])
    end_time = TimeField('End Time', validators=[DataRequired()])
    capacity = IntegerField('Capacity', validators=[Optional()], default=20)
    notes = TextAreaField('Notes', validators=[Optional()])
    submit = SubmitField('Save')


class AttendanceForm(FlaskForm):
    """Form for taking attendance for a class session."""
    status = SelectField('Status', choices=[
        ('present', 'Present'),
        ('absent', 'Absent'),
        ('late', 'Late')
    ])
    notes = TextAreaField('Notes', validators=[Optional()])


""" class PromotionForm(FlaskForm):
    Form for recording a belt promotion.
    new_belt = SelectField('New Belt', choices=[
        ('white', 'White'),
        ('blue', 'Blue'),
        ('purple', 'Purple'),
        ('brown', 'Brown'),
        ('black', 'Black')
    ])
    new_stripes = SelectField('New Stripes', choices=[
        ('0', '0'), ('1', '1'), ('2', '2'), ('3', '3'), ('4', '4')
    ], coerce=int)
    promotion_date = DateField('Promotion Date', validators=[DataRequired()])
    notes = TextAreaField('Notes', validators=[Optional()])
    submit = SubmitField('Record Promotion')
    def validate_new_belt(self, new_belt):
        if new_belt.data not in ['white', 'blue', 'purple', 'brown', 'black']:
            raise ValidationError('Invalid belt rank selected.')

    def validate_new_stripes(self, new_stripes):
        if new_stripes.data not in [0, 1, 2, 3, 4]:
            raise ValidationError('Invalid stripe count selected.') """
        
class PromotionForm(FlaskForm):
    # These fields are used to record the previous rank
    # They should be hidden in the HTML form
    previous_belt = StringField('Previous Belt')
    previous_stripes = IntegerField('Previous Stripes')
    
    # The user will fill in the new rank
    new_belt = SelectField('New Belt', choices=[
        ('blue', 'Blue Belt'),
        ('purple', 'Purple Belt'),
        ('brown', 'Brown Belt'),
        ('black', 'Black Belt')
    ], validators=[DataRequired()])
    new_stripes = IntegerField('New Stripes', validators=[DataRequired()])
    
    promotion_date = DateField('Promotion Date', validators=[DataRequired()])
    instructor_id = IntegerField('Instructor ID', validators=[DataRequired()])
    notes = TextAreaField('Notes')

ROLES = ['Coach','Assistant','Auxiliar','Admin','Front Desk']
STATUSES = [('active','Active'), ('inactive','Inactive')]
ACCESS = [('viewer','Viewer'), ('editor','Editor'), ('manager','Manager'), ('admin','Admin')]
PERMS = [
    ('attendance','Attendance'),
    ('billing','Billing'),
    ('members','Members'),
    ('reports','Reports'),
    ('staff','Staff'),
    ('settings','Settings'),
]

class StaffForm(FlaskForm):
    name = StringField('Full Name', validators=[DataRequired(), Length(max=160)])
    role = SelectField('Role', choices=[(r,r) for r in ROLES], validators=[DataRequired()])
    email = EmailField('Email', validators=[DataRequired(), Email(), Length(max=160)])
    phone = TelField('Phone', validators=[Optional(), Length(max=40)])
    specialties = StringField('Specialties (comma-separated)', validators=[Optional(), Length(max=400)])
    status = SelectField('Status', choices=STATUSES, validators=[DataRequired()])
    photo_url = URLField('Photo URL', validators=[Optional(), URL(), Length(max=500)])
    access_level = SelectField('Access Level', choices=ACCESS, validators=[DataRequired()])
    permissions = SelectMultipleField('Permissions', choices=PERMS, validators=[Optional()])
    submit = SubmitField('Save')

    def specialties_list(self):
        # turn "Gi, No-Gi, Kids" into ['Gi','No-Gi','Kids']
        if not self.specialties.data:
            return []
        return [s.strip() for s in self.specialties.data.split(',') if s.strip()]        