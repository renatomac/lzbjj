from datetime import datetime
from werkzeug.security import generate_password_hash, check_password_hash
from flask_login import UserMixin
from sqlalchemy.ext.declarative import declared_attr
from grapple import db
from sqlalchemy import func

# Association table for class attendance
class_attendance = db.Table(
    'class_attendance',
    db.Column('member_id', db.Integer, db.ForeignKey('members.id'), primary_key=True),
    db.Column('class_session_id', db.Integer, db.ForeignKey('class_sessions.id'), primary_key=True),
    db.Column('attendance_status', db.String(20), default='present'),  # present, absent, late
    db.Column('notes', db.Text),
    db.Column('created_at', db.DateTime, default=datetime.utcnow)
)

class TimestampMixin:
    @declared_attr
    def created_at(cls):
        return db.Column(db.DateTime, default=datetime.utcnow)
    
    @declared_attr
    def updated_at(cls):
        return db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

class User(UserMixin, TimestampMixin, db.Model):
    __tablename__ = 'users'
    
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(64), unique=True, index=True)
    email = db.Column(db.String(120), unique=True, index=True)
    password_hash = db.Column(db.String(128))
    first_name = db.Column(db.String(64))
    last_name = db.Column(db.String(64))
    role = db.Column(db.String(20), default='staff')  # admin, staff, instructor
    is_active = db.Column(db.Boolean, default=True)
    
    # Relationships
    classes = db.relationship('ClassSession', backref='instructor', lazy='dynamic')
    
    def set_password(self, password):
        self.password_hash = generate_password_hash(password)
    
    def check_password(self, password):
        return check_password_hash(self.password_hash, password)
    
    def full_name(self):
        return f"{self.first_name} {self.last_name}"
    
    def __repr__(self):
        return f'<User {self.username}>'

class Member(TimestampMixin, db.Model):
    __tablename__ = 'members'
    
    id = db.Column(db.Integer, primary_key=True)
    first_name = db.Column(db.String(64), nullable=False)
    last_name = db.Column(db.String(64), nullable=False)
    nickname = db.Column(db.String(64))
    email = db.Column(db.String(120), unique=True, index=True)
    phone = db.Column(db.String(20))
    date_of_birth = db.Column(db.Date)
    gender = db.Column(db.String(20))
    address = db.Column(db.String(128))
    city = db.Column(db.String(64))
    state = db.Column(db.String(2))
    zip_code = db.Column(db.String(10))
    emergency_contact_name = db.Column(db.String(64))
    emergency_contact_phone = db.Column(db.String(20))
    emergency_relationship = db.Column(db.String(64))
    medical_conditions = db.Column(db.Text)
    allergies = db.Column(db.Text)
    liability_waiver = db.Column(db.Boolean, default=False)
    photo_consent = db.Column(db.Boolean, default=False)
    email_consent = db.Column(db.Boolean, default=False)
    membership_plan_id = db.Column(db.Integer, db.ForeignKey('membership_plans.id'))
    belt_rank = db.Column(db.String(20), default='white')  # white, blue, purple, brown, black
    stripes = db.Column(db.Integer, default=0)
    join_date = db.Column(db.Date, default=datetime.utcnow().date)
    notes = db.Column(db.Text)
    is_active = db.Column(db.Boolean, default=True)
    
    # Relationships
    memberships = db.relationship('Membership', backref='member', lazy='dynamic')
    promotions = db.relationship('BeltPromotion', backref='member', lazy='dynamic')
    payments = db.relationship('Payment', backref='member', lazy='dynamic')
    attended_classes = db.relationship(
        'ClassSession',
        secondary=class_attendance,
        backref=db.backref('attendees', lazy='dynamic'),
        lazy='dynamic'
    )
    
    def full_name(self):
        return f"{self.first_name} {self.last_name}"
    
    def current_membership(self):
        today = datetime.utcnow().date()
        return self.memberships.filter(
            ((Membership.end_date >= today) | (Membership.end_date == None)) &
            (Membership.payment_status == 'active')
        ).order_by(Membership.start_date.desc()).first()
    
    def __repr__(self):
        return f'<Member {self.first_name} {self.last_name}>'

class MembershipPlan(TimestampMixin, db.Model):
    __tablename__ = 'membership_plans'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(64), nullable=False)
    description = db.Column(db.Text)
    price = db.Column(db.Numeric(10, 2), nullable=False)
    billing_frequency = db.Column(db.String(20), default='monthly')  # monthly, quarterly, annual
    classes_per_week = db.Column(db.Integer)
    is_active = db.Column(db.Boolean, default=True)
    
    # Relationships
    memberships = db.relationship('Membership', backref='plan', lazy='dynamic')
    
    def __repr__(self):
        return f'<MembershipPlan {self.name}>'

class Membership(TimestampMixin, db.Model):
    __tablename__ = 'memberships'
    
    id = db.Column(db.Integer, primary_key=True)
    member_id = db.Column(db.Integer, db.ForeignKey('members.id'), nullable=False)
    plan_id = db.Column(db.Integer, db.ForeignKey('membership_plans.id'), nullable=False)
    start_date = db.Column(db.Date, nullable=False)
    end_date = db.Column(db.Date)
    price_paid = db.Column(db.Numeric(10, 2))
    payment_status = db.Column(db.String(20), default='active')  # active, expired, cancelled
    notes = db.Column(db.Text)
    
    # Relationships
    payments = db.relationship('Payment', backref='membership', lazy='dynamic')
    
    def is_active(self):
        today = datetime.utcnow().date()
        return (self.end_date is None or self.end_date >= today) and self.payment_status == 'active'
    
    def __repr__(self):
        return f'<Membership {self.member_id}-{self.plan_id}>'

class Payment(TimestampMixin, db.Model):
    __tablename__ = 'payments'
    
    id = db.Column(db.Integer, primary_key=True)
    member_id = db.Column(db.Integer, db.ForeignKey('members.id'), nullable=False)
    membership_id = db.Column(db.Integer, db.ForeignKey('memberships.id'))
    amount = db.Column(db.Numeric(10, 2), nullable=False)
    payment_date = db.Column(db.DateTime, default=datetime.utcnow)
    payment_method = db.Column(db.String(20))  # credit_card, cash, check, bank_transfer
    status = db.Column(db.String(20), default='completed')  # completed, pending, failed, refunded
    transaction_id = db.Column(db.String(64))
    notes = db.Column(db.Text)
    
    def __repr__(self):
        return f'<Payment {self.id}>'

class BeltPromotion(TimestampMixin, db.Model):
    __tablename__ = 'belt_promotions'
    
    id = db.Column(db.Integer, primary_key=True)
    member_id = db.Column(db.Integer, db.ForeignKey('members.id'), nullable=False)
    previous_belt = db.Column(db.String(20), nullable=False)
    previous_stripes = db.Column(db.Integer, default=0)
    new_belt = db.Column(db.String(20), nullable=False)
    new_stripes = db.Column(db.Integer, default=0)
    promotion_date = db.Column(db.Date, nullable=False)
    instructor_id = db.Column(db.Integer, db.ForeignKey('users.id'))
    notes = db.Column(db.Text)
    
    # Relationships
    instructor = db.relationship('User', backref='promotions_given')
    
    def __repr__(self):
        return f'<BeltPromotion {self.id}>'

class ClassType(TimestampMixin, db.Model):
    __tablename__ = 'class_types'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(64), nullable=False)
    description = db.Column(db.Text)
    level = db.Column(db.String(20))  # beginner, intermediate, advanced, all-levels
    
    # Relationships
    sessions = db.relationship('ClassSession', backref='class_type', lazy='dynamic')
    
    def __repr__(self):
        return f'<ClassType {self.name}>'

class ClassSession(TimestampMixin, db.Model):
    __tablename__ = 'class_sessions'
    
    id = db.Column(db.Integer, primary_key=True)
    class_type_id = db.Column(db.Integer, db.ForeignKey('class_types.id'), nullable=False)
    instructor_id = db.Column(db.Integer, db.ForeignKey('users.id'))
    date = db.Column(db.Date, nullable=False)
    start_time = db.Column(db.Time, nullable=False)
    end_time = db.Column(db.Time, nullable=False)
    capacity = db.Column(db.Integer, default=20)
    notes = db.Column(db.Text)
    
    def __repr__(self):
        return f'<ClassSession {self.id}>'

class Promotion(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    belt = db.Column(db.String(50), nullable=False)
    promotion_date = db.Column(db.Date, nullable=False, default=datetime.utcnow)
    notes = db.Column(db.String(500), nullable=True)
    member_id = db.Column(db.Integer, db.ForeignKey('member.id'), nullable=False)

    def __repr__(self):
        return f'<Promotion {self.belt}>'


""" class Staff(db.Model):
    __tablename__ = 'staff'
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(160), nullable=False, index=True)
    role = db.Column(db.String(64), nullable=False, index=True)  # e.g., Coach, Assistant, Auxiliar, Admin, Front Desk
    email = db.Column(db.String(160), nullable=False, unique=True, index=True)
    phone = db.Column(db.String(40))
    # Prefer ARRAY for Postgres; if not available, switch to db.Text and store comma-separated
    specialties = db.Column(ARRAY(db.String), nullable=False, server_default='{}')  # ['Gi','No-Gi']
    status = db.Column(db.String(16), nullable=False, server_default='active')      # active | inactive
    access_level = db.Column(db.String(16), nullable=False, server_default='viewer')# viewer | editor | manager | admin
    permissions = db.Column(ARRAY(db.String), nullable=False, server_default='{}')  # ['attendance','members',...]
    photo_url = db.Column(db.Text)
    created_at = db.Column(db.DateTime, server_default=func.now())
    updated_at = db.Column(db.DateTime, onupdate=func.now())

class RolePermission(db.Model):
    __tablename__ = 'role_permissions'
    id = db.Column(db.Integer, primary_key=True)
    role = db.Column(db.String(64), nullable=False, unique=True, index=True)
    permissions = db.Column(ARRAY(db.String), nullable=False, server_default='{}')
    created_at = db.Column(db.DateTime, server_default=func.now()) 
    
class Staff(db.Model):
    __tablename__ = 'staff'

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(160), nullable=False, index=True)
    role = db.Column(db.String(64), nullable=False, index=True)      # e.g., Coach, Assistant, Auxiliar, Admin, Front Desk
    email = db.Column(db.String(160), nullable=False, unique=True, index=True)
    phone = db.Column(db.String(40))
    specialties = db.Column(db.JSON, nullable=False, default=list)    # JSON array, e.g., ["Gi","No-Gi"]
    status = db.Column(db.String(16), nullable=False, server_default='active')      # active | inactive
    access_level = db.Column(db.String(16), nullable=False, server_default='viewer')# viewer | editor | manager | admin
    permissions = db.Column(db.JSON, nullable=False, default=list)    # JSON array, e.g., ["attendance","members"]
    photo_url = db.Column(db.Text)
    created_at = db.Column(db.DateTime, server_default=func.now())
    updated_at = db.Column(db.DateTime, onupdate=func.now())

    # Safety helpers to ensure lists when reading (MySQL JSON returns Python types, but be defensive)
    @property
    def specialties_list(self):
        return self.specialties or []

    @specialties_list.setter
    def specialties_list(self, value):
        self.specialties = list(value or [])

    @property
    def permissions_list(self):
        return self.permissions or []

    @permissions_list.setter
    def permissions_list(self, value):
        self.permissions = list(value or [])


class RolePermission(db.Model):
    __tablename__ = 'role_permissions'

    id = db.Column(db.Integer, primary_key=True)
    role = db.Column(db.String(64), nullable=False, unique=True, index=True)
    permissions = db.Column(db.JSON, nullable=False, default=list)  # JSON array
    created_at = db.Column(db.DateTime, server_default=func.now())"""
    
    
    
class Staff(db.Model):
    __tablename__ = 'staff'

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(160), nullable=False, index=True)
    role = db.Column(db.String(64), nullable=False, index=True)      # e.g., Coach, Assistant, Auxiliar, Admin, Front Desk
    email = db.Column(db.String(160), nullable=False, unique=True, index=True)
    phone = db.Column(db.String(40))
    specialties = db.Column(db.JSON, nullable=False, default=list)    # JSON array, e.g., ["Gi","No-Gi"]
    status = db.Column(db.String(16), nullable=False, server_default='active')      # active | inactive
    access_level = db.Column(db.String(16), nullable=False, server_default='viewer')# viewer | editor | manager | admin
    permissions = db.Column(db.JSON, nullable=False, default=list)    # JSON array, e.g., ["attendance","members"]
    photo_url = db.Column(db.Text)
    created_at = db.Column(db.DateTime, server_default=func.now())
    updated_at = db.Column(db.DateTime, onupdate=func.now())

    # Safety helpers to ensure lists when reading (MySQL JSON returns Python types, but be defensive)
    @property
    def specialties_list(self):
        return self.specialties or []

    @specialties_list.setter
    def specialties_list(self, value):
        self.specialties = list(value or [])

    @property
    def permissions_list(self):
        return self.permissions or []

    @permissions_list.setter
    def permissions_list(self, value):
        self.permissions = list(value or [])


class RolePermission(db.Model):
    __tablename__ = 'role_permissions'

    id = db.Column(db.Integer, primary_key=True)
    role = db.Column(db.String(64), nullable=False, unique=True, index=True)
    permissions = db.Column(db.JSON, nullable=False, default=list)  # JSON array
    created_at = db.Column(db.DateTime, server_default=func.now())