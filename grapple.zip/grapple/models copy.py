from datetime import datetime
from werkzeug.security import generate_password_hash, check_password_hash
from flask_login import UserMixin
from sqlalchemy.ext.declarative import declared_attr
from grapple import db

# Association table for class attendance
class_attendance = db.Table(
    'class_attendance',
    db.Column('member_id', db.Integer, db.ForeignKey('members.id'), primary_key=True),
    db.Column('class_session_id', db.Integer, db.ForeignKey('class_sessions.id'), primary_key=True),
    db.Column('attendance_status', db.String(20), default='present'),  # present, absent, late
    db.Column('notes', db.Text),
    db.Column('created_at', db.DateTime, default=datetime.utcnow)
)

class TimestampMixin:
    @declared_attr
    def created_at(cls):
        return db.Column(db.DateTime, default=datetime.utcnow)
    
    @declared_attr
    def updated_at(cls):
        return db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

class User(UserMixin, TimestampMixin, db.Model):
    __tablename__ = 'users'
    
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(64), unique=True, index=True)
    email = db.Column(db.String(120), unique=True, index=True)
    password_hash = db.Column(db.String(128))
    first_name = db.Column(db.String(64))
    last_name = db.Column(db.String(64))
    role = db.Column(db.String(20), default='staff')  # admin, staff, instructor
    is_active = db.Column(db.Boolean, default=True)
    
    # Relationships
    classes = db.relationship('ClassSession', backref='instructor', lazy='dynamic')
    
    def set_password(self, password):
        self.password_hash = generate_password_hash(password)
    
    def check_password(self, password):
        return check_password_hash(self.password_hash, password)
    
    def full_name(self):
        return f"{self.first_name} {self.last_name}"
    
    def __repr__(self):
        return f''

class Member(TimestampMixin, db.Model):
    __tablename__ = 'members'
    
    id = db.Column(db.Integer, primary_key=True)
    first_name = db.Column(db.String(64), nullable=False)
    last_name = db.Column(db.String(64), nullable=False)
    email = db.Column(db.String(120), unique=True, index=True)
    phone = db.Column(db.String(20))
    date_of_birth = db.Column(db.Date)
    address = db.Column(db.String(128))
    city = db.Column(db.String(64))
    state = db.Column(db.String(2))
    zip_code = db.Column(db.String(10))
    emergency_contact_name = db.Column(db.String(64))
    emergency_contact_phone = db.Column(db.String(20))
    belt_rank = db.Column(db.String(20), default='white')  # white, blue, purple, brown, black
    stripes = db.Column(db.Integer, default=0)
    join_date = db.Column(db.Date, default=datetime.utcnow().date)
    notes = db.Column(db.Text)
    is_active = db.Column(db.Boolean, default=True)
    
    # Relationships
    memberships = db.relationship('Membership', backref='member', lazy='dynamic')
    promotions = db.relationship('BeltPromotion', backref='member', lazy='dynamic')
    payments = db.relationship('Payment', backref='member', lazy='dynamic')
    attended_classes = db.relationship(
        'ClassSession',
        secondary=class_attendance,
        backref=db.backref('attendees', lazy='dynamic'),
        lazy='dynamic'
    )
    
    def full_name(self):
        return f"{self.first_name} {self.last_name}"
    
    def current_membership(self):
        today = datetime.utcnow().date()
        return self.memberships.filter(
            ((Membership.end_date >= today) | (Membership.end_date == None)) &
            (Membership.payment_status == 'active')
        ).order_by(Membership.start_date.desc()).first()
    
    def __repr__(self):
        return f''

class MembershipPlan(TimestampMixin, db.Model):
    __tablename__ = 'membership_plans'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(64), nullable=False)
    description = db.Column(db.Text)
    price = db.Column(db.Numeric(10, 2), nullable=False)
    billing_frequency = db.Column(db.String(20), default='monthly')  # monthly, quarterly, annual
    classes_per_week = db.Column(db.Integer)
    is_active = db.Column(db.Boolean, default=True)
    
    # Relationships
    memberships = db.relationship('Membership', backref='plan', lazy='dynamic')
    
    def __repr__(self):
        return f''

class Membership(TimestampMixin, db.Model):
    __tablename__ = 'memberships'
    
    id = db.Column(db.Integer, primary_key=True)
    member_id = db.Column(db.Integer, db.ForeignKey('members.id'), nullable=False)
    plan_id = db.Column(db.Integer, db.ForeignKey('membership_plans.id'), nullable=False)
    start_date = db.Column(db.Date, nullable=False)
    end_date = db.Column(db.Date)
    price_paid = db.Column(db.Numeric(10, 2))
    payment_status = db.Column(db.String(20), default='active')  # active, expired, cancelled
    notes = db.Column(db.Text)
    
    # Relationships
    payments = db.relationship('Payment', backref='membership', lazy='dynamic')
    
    def is_active(self):
        today = datetime.utcnow().date()
        return (self.end_date is None or self.end_date >= today) and self.payment_status == 'active'
    
    def __repr__(self):
        return f''

class Payment(TimestampMixin, db.Model):
    __tablename__ = 'payments'
    
    id = db.Column(db.Integer, primary_key=True)
    member_id = db.Column(db.Integer, db.ForeignKey('members.id'), nullable=False)
    membership_id = db.Column(db.Integer, db.ForeignKey('memberships.id'))
    amount = db.Column(db.Numeric(10, 2), nullable=False)
    payment_date = db.Column(db.DateTime, default=datetime.utcnow)
    payment_method = db.Column(db.String(20))  # credit_card, cash, check, bank_transfer
    status = db.Column(db.String(20), default='completed')  # completed, pending, failed, refunded
    transaction_id = db.Column(db.String(64))
    notes = db.Column(db.Text)
    
    def __repr__(self):
        return f''

class BeltPromotion(TimestampMixin, db.Model):
    __tablename__ = 'belt_promotions'
    
    id = db.Column(db.Integer, primary_key=True)
    member_id = db.Column(db.Integer, db.ForeignKey('members.id'), nullable=False)
    previous_belt = db.Column(db.String(20), nullable=False)
    previous_stripes = db.Column(db.Integer, default=0)
    new_belt = db.Column(db.String(20), nullable=False)
    new_stripes = db.Column(db.Integer, default=0)
    promotion_date = db.Column(db.Date, nullable=False)
    instructor_id = db.Column(db.Integer, db.ForeignKey('users.id'))
    notes = db.Column(db.Text)
    
    # Relationships
    instructor = db.relationship('User', backref='promotions_given')
    
    def __repr__(self):
        return f''

class ClassType(TimestampMixin, db.Model):
    __tablename__ = 'class_types'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(64), nullable=False)
    description = db.Column(db.Text)
    level = db.Column(db.String(20))  # beginner, intermediate, advanced, all-levels
    
    # Relationships
    sessions = db.relationship('ClassSession', backref='class_type', lazy='dynamic')
    
    def __repr__(self):
        return f''

class ClassSession(TimestampMixin, db.Model):
    __tablename__ = 'class_sessions'
    
    id = db.Column(db.Integer, primary_key=True)
    class_type_id = db.Column(db.Integer, db.ForeignKey('class_types.id'), nullable=False)
    instructor_id = db.Column(db.Integer, db.ForeignKey('users.id'))
    date = db.Column(db.Date, nullable=False)
    start_time = db.Column(db.Time, nullable=False)
    end_time = db.Column(db.Time, nullable=False)
    capacity = db.Column(db.Integer, default=20)
    notes = db.Column(db.Text)
    
    def __repr__(self):
        return f''